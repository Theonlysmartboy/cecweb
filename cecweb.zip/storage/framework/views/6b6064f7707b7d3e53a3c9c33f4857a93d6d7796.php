<!-- Nav Menu -->
<header>
    <div class="top_header" id="home">
		<!-- Fixed navbar -->
		<nav class="navbar navbar-default navbar-fixed-top">
			<div class="nav_top_fx_w3ls_agileinfo">
				<div class="navbar-header">
					<button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false"
					    aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
					<div class="logo-w3layouts-agileits">
						<h1> <a class="navbar-brand" href="<?php echo e(route('index')); ?>"><img src="<?php echo e(asset('images/icons/logo.png')); ?>" alt="CEC logo" class="img-responsive" style="width: 50px; height: 50px;"/></a></h1>
					</div>
				</div>
				<div id="navbar" class="navbar-collapse collapse">
					<div class="nav_right_top">
						<ul class="nav navbar-nav">
							<li class="<?php if(Route::current()->getName() == 'index'): ?> active <?php endif; ?>"><a href="<?php echo e(route('index')); ?>">Home</a></li>
							<li class="<?php if(Route::current()->getName() == 'about_us'): ?> active <?php endif; ?>"><a href="<?php echo e(route('about_us')); ?>">About</a></li>
							<li class="dropdown <?php if(Request::is('ministries/*')): ?> active <?php endif; ?>">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Ministries <span class="caret"></span></a>
								<ul class="dropdown-menu">
									<?php $__currentLoopData = $ministries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ministry): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li><a href="<?php echo e(route('ministries.show', [$ministry->id])); ?>"><?php echo e($ministry->name); ?></a></li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							</li>
							<li class="dropdown <?php if(Request::is('branches/*')): ?> active <?php endif; ?>">
								<a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Churches <span class="caret"></span></a>
								<ul class="dropdown-menu">
									<?php $__currentLoopData = $branches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li><a href="<?php echo e(route('branches.show', [$branch->id])); ?>"><?php echo e($branch->name); ?></a></li>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</ul>
							</li>
							<li class="<?php if(Route::current()->getName() == 'gallery.index'): ?> active <?php endif; ?>"><a href="<?php echo e(route('gallery.index')); ?>">Gallery</a></li>
							<li class="<?php if(Route::current()->getName() == 'news.index'): ?> active <?php endif; ?>"><a href="<?php echo e(route('news.index')); ?>">Posts</a></li>
							<li class="<?php if(Route::current()->getName() == 'contact_us'): ?> active <?php endif; ?>"><a href="<?php echo e(route('contact_us')); ?>">Contact Us</a></li>
						</ul>
					</div>
				</div>
				<!--/.nav-collapse -->
			</div>
		</nav>
	</div>
</header>
  <?php /**PATH C:\xampp\htdocs\cecweb\resources\views/layouts/front_layout/header.blade.php ENDPATH**/ ?>
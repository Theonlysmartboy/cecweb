<!-- Control Sidebar -->
<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->

  <!-- Main Footer -->
  <footer class="main-footer">
    <strong>Copyright &copy; 2015-2020 <a href="http://otemainc.com">Otema Technologies</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Version</b> 1.0.5
    </div>
  </footer><?php /**PATH C:\xampp\htdocs\cecweb\resources\views/layouts/back_layout/footer.blade.php ENDPATH**/ ?>